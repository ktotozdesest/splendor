import os
import sys
import pygame


def load_image(name, colorkey=None):
    fullname = os.path.join('C:\\Users\\1\\Desktop\\sprite', name)
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    if colorkey is not None:
        image = image.convert()
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image


if __name__ == '__main__':
    pygame.init()
    try:
        size = 1000, 700
        screen = pygame.display.set_mode(size)
        player_number = 4
        gem_list = [7 for _ in range(6)] + [5]
        inventory_gems = [0 for _ in range(6)]
        running = True
        while running:

            all_sprites = pygame.sprite.Group()
            # задний план
            sprite = pygame.sprite.Sprite(all_sprites)
            sprite.image = load_image("background.jpg")
            sprite.image = pygame.transform.scale(sprite.image, (2000, 1500))
            sprite.rect = sprite.image.get_rect()
            # фон инвентаря
            sprite = pygame.sprite.Sprite(all_sprites)
            sprite.image = load_image("inventory.jpg")
            sprite.image = pygame.transform.scale(sprite.image,
                                                  (sprite.image.get_size()[0] / sprite.image.get_size()[1] * size[1],
                                                   size[1]))
            sprite.rect = sprite.image.get_rect()
            sprite.rect.x = size[0] - 300 * (size[0] / 1024)
            # размещение карт
            for i in range(15):
                sprite = pygame.sprite.Sprite(all_sprites)
                sprite.image = pygame.transform.scale(load_image("diamond_mine.png"), (85 * (size[0] / 1024),
                                                                                       120 * (size[0] / 1024)))
                sprite.rect = sprite.image.get_rect()
                sprite.rect.x = 105 * (size[0] / 1024) * (i // 3) + 50 * (size[0] / 1024)
                sprite.rect.y = 150 * (i % 3) * (size[0] / 1024) + 125 * (size[0] / 1024)
            # вельможи
            for i in range(player_number + 1):
                sprite = pygame.sprite.Sprite(all_sprites)
                sprite.image = pygame.transform.scale(load_image("ruby.png"), (85 * (size[0] / 1024),
                                                                               85 * (size[0] / 1024)))
                sprite.rect = sprite.image.get_rect()
                sprite.rect.x = 105 * (size[0] / 1024) * i + 50 * (size[0] / 1024)
                sprite.rect.y = 25 * (size[0] / 1024)
            # ресурсы
            for i in range(7):
                sprite = pygame.sprite.Sprite(all_sprites)
                sprite.image = pygame.transform.scale(load_image("emerald.png"), (50 * (size[0] / 1024),
                                                                                  50 * (size[0] / 1024)))
                sprite.rect = sprite.image.get_rect()
                sprite.rect.x = 575 * (size[0] / 1024)
                sprite.rect.y = 62 * (size[0] / 1024) * i + 123 * (size[0] / 1024)
            # игроки
            for i in range(player_number):
                sprite = pygame.sprite.Sprite(all_sprites)
                sprite.image = pygame.transform.scale(load_image("ruby.png"), (85 * (size[0] / 1024),
                                                                               85 * (size[0] / 1024)))
                sprite.rect = sprite.image.get_rect()
                sprite.rect.x = 105 * (size[0] / 1024) * i + 50 * (size[0] / 1024)
                sprite.rect.y = size[1] - (25 * (size[0] / 1024) + sprite.image.get_size()[1])
            all_sprites.draw(screen)
            for i in range(6):
                # кол-во ресов в свободном доступе
                font = pygame.font.Font(None, int(50 * (size[0] / 1024)))
                text = font.render(f"{gem_list[i]} / 7", True, (0, 0, 0))
                screen.blit(text, (635 * (size[0] / 1024), 62 * (size[0] / 1024) * i + 130 * (size[0] / 1024)))
                # в инвентаре
                font = pygame.font.Font(None, int(30 * (size[0] / 1024)))
                text = font.render(f"{inventory_gems[i]}", True, (0, 0, 0))
                screen.blit(text, (size[0] - 60 * (size[0] / 1024), 30 * (size[0] / 1024) * i + 25 * (size[0] / 1024)))
            # аналогично для золота
            font = pygame.font.Font(None, int(50 * (size[0] / 1024)))
            text = font.render(f"{gem_list[-1]} / 5", True, (0, 0, 0))
            screen.blit(text, (635 * (size[0] / 1024), 62 * (size[0] / 1024) * 6 + 130 * (size[0] / 1024)))

            font = pygame.font.Font(None, int(30 * (size[0] / 1024)))
            text = font.render(f"{inventory_gems[-1]}", True, (0, 0, 0))
            screen.blit(text, (size[0] - 60 * (size[0] / 1024), 30 * (size[0] / 1024) * 6 + 25 * (size[0] / 1024)))

            pygame.display.flip()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

    except Exception as e:
        print(e)

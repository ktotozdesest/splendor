import os
import sys
import pygame
from image_for_sprite import *
from pathlib import Path
from random import *


class GameRender:
    def __init__(self, surface, player_number, card_list, earl_list):
        self.player_number = player_number
        pn = self.player_number
        if pn == 4:
            self.gemn = 7
        else:
            self.gemn = pn + 2
        self.gem_list = [self.gemn for _ in range(5)] + [5]
        self.inventory_gems = [0 for _ in range(6)]
        self.screen = surface
        self.card_list = card_list
        self.earl_list = earl_list


    def render(self):
        all_sprites = pygame.sprite.Group()
        # задний план - заглушка
        sprite = pygame.sprite.Sprite(all_sprites)
        sprite.image = load_image("background.jpg")
        sprite.image = pygame.transform.scale(sprite.image, (2000, 1500))
        sprite.rect = sprite.image.get_rect()
        # фон инвентаря - заглушка
        sprite = pygame.sprite.Sprite(all_sprites)
        sprite.image = load_image("inventory.jpg")
        sprite.image = pygame.transform.scale(sprite.image,
                                              (sprite.image.get_size()[0] / sprite.image.get_size()[1] * size[1],
                                               size[1]))
        sprite.rect = sprite.image.get_rect()
        sprite.rect.x = size[0] - 300 * (size[1] / 1000)
        # размещение уровней
        card_dir = Path('data/cards/')
        card_move = 0
        for card_lv in card_dir.glob('card_*'):
            sprite = pygame.sprite.Sprite(all_sprites)
            sprite.image = pygame.transform.scale(load_image_card(card_lv), (120 * (size[1] / 1000),
                                                                             170 * (size[1] / 1000)))
            sprite.rect = sprite.image.get_rect()
            sprite.rect.x = 50 * (size[1] / 1000)
            sprite.rect.y = 200 * (size[1] / 1000) * card_move + 185 * (size[1] / 1000)
            card_move += 1
        # размещение карт
        for i in range(12):
            sprite = pygame.sprite.Sprite(all_sprites)
            sprite.image = pygame.transform.scale(load_image_card(f'data/cards/{self.card_list[i]}_mine.png'),
                                                  (120 * (size[1] / 1000), 170 * (size[1] / 1000)))
            sprite.rect = sprite.image.get_rect()
            sprite.rect.x = 50 * (size[1] / 1000) + 150 * (size[1] / 1000) * (i % 4 + 1)
            sprite.rect.y = 200 * (size[1] / 1000) * (i // 4) + 185 * (size[1] / 1000)

        # вельможи
        for i in range(self.player_number + 1):
            sprite = pygame.sprite.Sprite(all_sprites)
            sprite.image = pygame.transform.scale(load_image_earl(f"earl{self.earl_list[i]}.png"),
                                                  (120 * (size[1] / 1000), 120 * (size[1] / 1000)))
            sprite.rect = sprite.image.get_rect()
            sprite.rect.x = 150 * (size[1] / 1000) * i + 50 * (size[1] / 1000)
            sprite.rect.y = 50 * (size[1] / 1000)
        # ресурсы
        gem_dir = Path('data/gems/')
        gem_move = 0
        for gem in gem_dir.glob('*'):
            sprite = pygame.sprite.Sprite(all_sprites)
            sprite.image = pygame.transform.scale(load_image_gem(gem), (80 * (size[1] / 1000),
                                                                        80 * (size[1] / 1000)))
            sprite.rect = sprite.image.get_rect()
            sprite.rect.x = 800 * (size[1] / 1000)
            sprite.rect.y = 100 * (size[1] / 1000) * gem_move + 175 * (size[1] / 1000)
            gem_move += 1
        # игроки
        for i in range(self.player_number):
            sprite = pygame.sprite.Sprite(all_sprites)
            sprite.image = pygame.transform.scale(load_image("ava.png"), (120 * (size[1] / 1000),
                                                                          120 * (size[1] / 1000)))
            sprite.rect = sprite.image.get_rect()
            sprite.rect.x = 150 * (size[1] / 1000) * i + 50 * (size[1] / 1000)
            sprite.rect.y = size[1] - (50 * (size[1] / 1000) + sprite.image.get_size()[1])
        all_sprites.draw(screen)
        for i in range(5):
            # кол-во ресов в свободном доступе
            font = pygame.font.Font(None, int(75 * (size[1] / 1000)))
            text = font.render(f"{self.gem_list[i]} / {self.gemn}", True, (0, 0, 0))
            screen.blit(text, (900 * (size[1] / 1000), 100 * (size[1] / 1000) * i + 180 * (size[1] / 1000)))
            # в инвентаре
            font = pygame.font.Font(None, int(30 * (size[1] / 1000)))
            text = font.render(f"{self.inventory_gems[i]}", True, (0, 0, 0))
            screen.blit(text, (size[0] - 60 * (size[1] / 1000), 30 * (size[1] / 1000) * i + 25 * (size[1] / 1000)))
        # аналогично для золота
        font = pygame.font.Font(None, int(75 * (size[1] / 1000)))
        text = font.render(f"{self.gem_list[-1]} / 5", True, (0, 0, 0))
        screen.blit(text, (900 * (size[1] / 1000), 100 * (size[1] / 1000) * 5 + 180 * (size[1] / 1000)))

        font = pygame.font.Font(None, int(30 * (size[1] / 1000)))
        text = font.render(f"{self.inventory_gems[-1]}", True, (0, 0, 0))
        screen.blit(text, (size[0] - 60 * (size[1] / 1000), 30 * (size[1] / 1000) * 5 + 25 * (size[1] / 1000)))


if __name__ == '__main__':
    pygame.init()
    try:
        size = 1900, 1000
        screen = pygame.display.set_mode(size)
        print(type(screen))
        # заполнил случайным образом для проверки
        gems = ['diamond', 'emerald', 'onyx', 'ruby', 'sapphire']
        cards = [choice(gems) for _ in range(12)]
        earls = list(range(1, 6))
        shuffle(earls)
        game = GameRender(screen, 4, cards, earls)
        running = True
        while running:
            game.render()
            pygame.display.flip()
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

    except Exception as e:
        print(e)

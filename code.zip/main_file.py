import pygame
import sys
import os
import pygame_textinput
import urllib.parse as up
import psycopg2
import time
from threading import Thread
import random
import checkbox

pygame.init()
info = pygame.display.Info()
weight, height = 300, 340
sc = pygame.display.set_mode((weight, height))
pygame.display.set_caption('Splendor')

command = [(0, 0), (1, 13), (2, 13), (3, 13)]
is_connected = True
player_id = 0
is_host = True

count_of_players = 0
id_last_command = 0
code = [77, 77]
gems = [7, 7, 7, 7, 7, 5]

players = []

RESOLUTIONS = {'r0': '1366x768', 'r1': '1920x1080', 'r2': '1536x864',
               'r3': '1440x900', 'r4': '1280x720', 'r5': '1600x900',
               'r6': '1280x800', 'r7': '1280x1024', 'r8': '1024x768'}

can_be_start = False
# первая цифра ряд вторая ресурс третья очки множество стоимость 1 ряд 0-7 8-15 16-23 24-31 32-39
# 2 ряд 40-45 46-51 52-57 58-63 64-69 3 ряд 70-73 74-77 78-81 82-85 86-89
# красный 0 зелёный 1 чёрный 2 синий 3 белый 4
CARDS = {0: [0, 0, 0, (1, 0, 3, 0, 1)], 1: [0, 0, 1, (0, 0, 0, 0, 4)], 2: [0, 0, 0, (0, 1, 2, 0, 2)],
         3: [0, 0, 0, (0, 1, 1, 1, 1)],
         4: [0, 0, 0, (0, 1, 0, 2, 0)], 5: [0, 0, 0, (0, 0, 0, 0, 3)], 6: [0, 0, 0, (2, 0, 0, 0, 2)],
         7: [0, 0, 0, (0, 1, 1, 1, 2)],
         8: [0, 1, 0, (2, 0, 2, 1, 0)], 9: [0, 1, 0, (3, 0, 0, 0, 0)], 10: [0, 1, 0, (2, 0, 0, 2, 0)],
         11: [0, 1, 0, (1, 0, 1, 1, 1)],
         12: [0, 1, 0, (0, 1, 0, 3, 1)], 13: [0, 1, 0, (1, 0, 2, 1, 1)], 14: [0, 1, 0, (0, 0, 0, 1, 2)],
         15: [0, 1, 1, (0, 0, 4, 0, 0)],
         16: [0, 2, 0, (1, 0, 0, 2, 2)], 17: [0, 2, 0, (1, 1, 0, 1, 1)], 18: [0, 2, 0, (3, 1, 1, 0, 0)],
         19: [0, 2, 1, (0, 0, 0, 4, 0)],
         20: [0, 2, 0, (0, 3, 0, 0, 0)], 21: [0, 2, 0, (0, 2, 0, 0, 2)], 22: [0, 2, 0, (1, 2, 0, 0, 0)],
         23: [0, 2, 0, (1, 1, 0, 2, 1)],
         24: [0, 3, 1, (4, 0, 0, 0, 0)], 25: [0, 3, 0, (2, 2, 0, 0, 1)], 26: [0, 3, 0, (0, 0, 3, 0, 0)],
         27: [0, 3, 0, (1, 1, 0, 1, 1)],
         28: [0, 3, 0, (1, 3, 0, 1, 0)], 29: [0, 3, 0, (0, 0, 2, 0, 1)], 30: [0, 3, 0, (2, 1, 1, 0, 1)],
         31: [0, 3, 0, (0, 2, 2, 0, 0)],
         32: [0, 4, 0, (1, 2, 1, 1, 0)], 33: [0, 4, 0, (2, 0, 1, 0, 0)], 34: [0, 4, 0, (0, 0, 3, 0, 0)],
         35: [0, 4, 0, (0, 0, 2, 2, 0)],
         36: [0, 4, 0, (0, 2, 1, 2, 0)], 37: [0, 4, 1, (0, 4, 0, 0, 0)], 38: [0, 4, 0, (1, 1, 1, 1, 0)],
         39: [0, 4, 0, (0, 0, 1, 1, 3)],

         40: [1, 0, 2, (0, 0, 5, 0, 0)], 41: [1, 0, 3, (6, 0, 0, 0, 0)], 42: [1, 0, 2, (0, 0, 5, 0, 3)],
         43: [1, 0, 2, (0, 2, 0, 4, 1)], 44: [1, 0, 1, (2, 0, 3, 0, 2)], 45: [1, 0, 1, (2, 0, 3, 3, 0)],
         46: [1, 1, 2, (0, 3, 0, 5, 0)], 47: [1, 1, 1, (3, 2, 0, 0, 3)], 48: [1, 1, 3, (0, 6, 0, 0, 0)],
         49: [1, 1, 2, (0, 0, 1, 2, 4)], 50: [1, 1, 2, (0, 5, 0, 0, 0)], 51: [1, 1, 2, (0, 0, 2, 3, 2)],
         52: [1, 2, 2, (2, 4, 0, 1, 0)], 53: [1, 2, 3, (0, 0, 6, 0, 0)], 54: [1, 2, 2, (3, 5, 0, 0, 0)],
         55: [1, 2, 1, (0, 2, 0, 2, 3)], 56: [1, 2, 2, (0, 0, 0, 0, 5)], 57: [1, 2, 1, (0, 3, 2, 0, 3)],
         58: [1, 3, 1, (0, 3, 3, 2, 0)], 59: [1, 3, 3, (0, 0, 0, 6, 0)], 60: [1, 3, 1, (3, 2, 0, 2, 0)],
         61: [1, 3, 2, (0, 0, 0, 3, 5)], 62: [1, 3, 2, (1, 0, 4, 0, 2)], 63: [1, 3, 2, (0, 0, 0, 5, 0)],
         64: [1, 4, 2, (5, 0, 0, 0, 0)], 65: [1, 4, 1, (3, 0, 0, 3, 2)], 66: [1, 4, 2, (5, 0, 3, 0, 0)],
         67: [1, 4, 1, (2, 3, 2, 0, 0)], 68: [1, 4, 2, (4, 1, 2, 0, 0)], 69: [1, 4, 3, (0, 0, 0, 0, 6)],

         70: [2, 0, 5, (3, 7, 0, 0, 0)], 71: [2, 0, 4, (0, 7, 0, 0, 0)],
         72: [2, 0, 3, (0, 3, 0, 5, 3)], 73: [2, 0, 4, (3, 6, 0, 3, 0)],
         74: [2, 1, 4, (0, 0, 0, 7, 0)], 75: [2, 1, 5, (0, 3, 0, 7, 0)],
         76: [2, 1, 3, (3, 0, 3, 3, 5)], 77: [2, 1, 4, (0, 3, 0, 6, 3)],
         78: [2, 2, 5, (7, 0, 3, 0, 0)], 79: [2, 2, 4, (6, 3, 3, 0, 0)],
         80: [2, 2, 3, (3, 5, 0, 3, 3)], 81: [2, 2, 4, (7, 0, 0, 0, 0)],
         82: [2, 3, 5, (0, 0, 0, 3, 7)], 83: [2, 3, 3, (3, 3, 5, 0, 3)],
         84: [2, 3, 4, (0, 0, 0, 0, 7)], 85: [2, 3, 4, (0, 0, 3, 3, 6)],
         86: [2, 4, 4, (3, 0, 6, 0, 3)], 87: [2, 4, 5, (0, 0, 7, 0, 3)],
         88: [2, 4, 4, (0, 0, 7, 0, 0)], 89: [2, 4, 3, (5, 3, 3, 3, 0)]
         }


def load_image(name, colorkey=None):
    fullname = os.path.join('data/other', name)
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    if colorkey is not None:
        image = image.convert()
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image


def load_image_gem(name, colorkey=None):
    fullname = os.path.join('data/gems', name)
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    if colorkey is not None:
        image = image.convert()
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image


def load_image_card(name, colorkey=None):
    fullname = os.path.join('data/cards', name)
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    if colorkey is not None:
        image = image.convert()
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image


class Gem(pygame.sprite.Sprite):
    def __init__(self, name, pos, *group):
        super().__init__(*group)
        self.flag = True
        image = load_image_gem(name)
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.x = pos[0]
        self.rect.y = pos[1]


class Card(pygame.sprite.Sprite):
    def __init__(self, name, pos, *group):
        super().__init__(*group)
        self.flag = True
        image = load_image_gem(name)
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.x = pos[0]
        self.rect.y = pos[1]
        self.pos = pos


class StartWindow:
    def __init__(self, screen, weight_of_window, height_of_window):
        self.screen = screen

        self.recommended_resolution = f'{weight_of_window}x{height_of_window}'

        self.font1 = pygame.font.Font(None, 24)
        self.font2 = pygame.font.Font(None, 20)
        self.font3 = pygame.font.Font(None, 52)
        self.header = self.font3.render('Splendor', True, (0, 0, 0))
        self.now_resolution_text = self.font1.render(self.recommended_resolution,
                                                     True, (0, 0, 0))
        self.text = self.font1.render("Разрешение", True, (0, 0, 0))
        self.save_resolution_1 = self.font2.render('Сохранить и', True, (0, 0, 0))
        self.save_resolution_2 = self.font2.render(' больше не показывать', True, (0, 0, 0))

        self.full_screen = self.font2.render('Полный экран', True, (0, 0, 0))

        self.next = self.font1.render('Далее', True, (0, 0, 0))

        self.is_full_screen = 0

        self.is_expand = False
        self.is_save = 0
        self.y = {'y_line1': 220, 'y_line2': 240}
        self.resolution_index = 0
        self.is_selected = [0, 0, 0]
        self.now_resolution = self.recommended_resolution

    def render(self):
        self.screen.fill(pygame.Color(255, 255, 255))

        self.screen.blit(self.text, (91, 162))
        self.screen.blit(self.header, (72, 40))

        self.screen.blit(self.now_resolution_text, (91, 182))
        pygame.draw.rect(self.screen, pygame.Color(0, 0, 0), (80, 180, 140, 20), 1)

        pygame.draw.rect(self.screen, pygame.Color(0, 0, 0), (202, 182, 16, 16), 1)

        pygame.draw.line(self.screen, pygame.Color(0, 0, 0), (206, 188), (209, 192), 2)
        pygame.draw.line(self.screen, pygame.Color(0, 0, 0), (209, 192), (212, 188), 2)

        pygame.draw.rect(self.screen, pygame.Color(0, 0, 0), (20, 260, 20, 20), 1)
        self.screen.blit(self.save_resolution_1, (40, 260))
        self.screen.blit(self.save_resolution_2, (40, 270))

        pygame.draw.rect(self.screen, pygame.Color(0, 0, 0), (220, 290, 60, 20), 1)
        self.screen.blit(self.next, (222, 292))

        pygame.draw.rect(self.screen, pygame.Color(0, 0, 0), (20, 290, 20, 20), 1)
        self.screen.blit(self.full_screen, (40, 295))

        if self.is_save:
            pygame.draw.line(self.screen, pygame.Color(0, 0, 0), (24, 268), (30, 276), 3)
            pygame.draw.line(self.screen, pygame.Color(0, 0, 0), (30, 276), (36, 264), 3)

        if self.is_full_screen:
            pygame.draw.line(self.screen, pygame.Color(0, 0, 0), (24, 298), (30, 306), 3)
            pygame.draw.line(self.screen, pygame.Color(0, 0, 0), (30, 306), (36, 294), 3)

        if self.is_expand:
            if 1 in self.is_selected:
                selected_section = self.is_selected.index(1)
                pygame.draw.rect(self.screen, pygame.Color(42, 156, 235),
                                 (80, 200 + selected_section * 20, 120, 20), 0)

            pygame.draw.rect(self.screen, pygame.Color(0, 0, 0), (80, 200, 140, 60), 1)
            pygame.draw.rect(self.screen, pygame.Color(0, 0, 0), (200, 200, 20, 60), 1)

            pygame.draw.rect(self.screen, pygame.Color(0, 0, 0), (202, 202, 16, 16), 1)
            pygame.draw.rect(self.screen, pygame.Color(0, 0, 0), (202, 242, 16, 16), 1)

            pygame.draw.line(self.screen, pygame.Color(0, 0, 0), (206, 248), (209, 252), 2)
            pygame.draw.line(self.screen, pygame.Color(0, 0, 0), (209, 252), (212, 248), 2)

            pygame.draw.line(self.screen, pygame.Color(0, 0, 0), (206, 212), (209, 208), 2)
            pygame.draw.line(self.screen, pygame.Color(0, 0, 0), (209, 208), (212, 212), 2)

            for i in range(2):
                pygame.draw.line(self.screen, pygame.Color(0, 0, 0), (80, self.y[f'y_line{i + 1}']),
                                 (200, self.y[f'y_line{i + 1}']), 1)
            for i in range(3):
                resolution = self.font1.render(RESOLUTIONS[f'r{(self.resolution_index + i) % 9}'], True, (0, 0, 0))
                self.screen.blit(resolution, (91, 202 + i * 20))

    def expand(self):
        self.is_expand = (self.is_expand + 1) % 2

    def up(self):
        self.resolution_index -= 1

    def down(self):
        self.resolution_index += 1

    def select(self, section):
        if self.is_selected[section] == 1:
            self.now_resolution = RESOLUTIONS[f'r{(self.resolution_index + section) % 9}']
            self.now_resolution_text = self.font1.render(self.now_resolution,
                                                         True, (0, 0, 0))
        self.is_selected = [0] * 3
        self.is_selected[section] = 1

    def save_resolution(self):
        self.is_save = (self.is_save + 1) % 2

    def change_full_screen(self):
        self.is_full_screen = (self.is_full_screen + 1) % 2

    def save_settings(self):
        f1 = open('data/other/settings.txt', mode='r')
        setting_res = f1.read().split('\n')
        f1.close()
        f1 = open('data/other/settings.txt', mode='w')
        setting_res[0] = self.now_resolution
        setting_res[1] = str(self.is_save)
        setting_res[2] = str(self.is_full_screen)
        for i in range(len(setting_res) - 1):
            setting_res[i] = setting_res[i] + '\n'
        for elem in setting_res:
            f1.write(elem)
        f1.close()

    def render_preplay_win(self):
        font = pygame.font.Font('data/other/Standrag.otf', 100)
        counter_of_players = font.render(str(count_of_players), True, (255, 255, 0))
        sc.blit(counter_of_players, (weight // 2, height // 2))


def connection(link):
    try:
        up.uses_netloc.append("postgres")
        url = up.urlparse(link)

        conn = psycopg2.connect(database=url.path[1:], user=url.username, password=url.password,
                                host=url.hostname,
                                port=url.port)
        return conn
    except psycopg2.OperationalError:
        global is_connected
        is_connected = False


def update(conn):
    cur = conn.cursor()
    cur.execute("""SELECT * FROM codes;""")
    result = cur.fetchall()
    cur.close()
    return result


def create_table(conn):
    cur = conn.cursor()
    is_be = cur.execute("""select * from pg_tables where tablename = 'codes';""")
    cur.execute("""DROP TABLE codes""")
    if not is_be:
        cur.execute("""CREATE TABLE IF NOT EXISTS codes (
                        id integer,
                        code integer);""")
        for i in range(4):
            print(True)
            cur.execute(f"""INSERT INTO codes VALUES ({i}, 0);""")
    cur.close()
    conn.commit()


def do_move(conn, move):
    cur = conn.cursor()
    for i in range(4):
        cur.execute(f"""UPDATE codes SET code={move[i]} WHERE id = {i}""")
    cur.close()
    conn.commit()


def online():
    if is_connected:
        global command
        global count_of_players
        global id_last_command
        global player_id
        command = update(connection(link))
        if command[0][1] != id_last_command:
            if command[1][1] == 0:
                code = [command[2][1] // 100, command[2][1] // 10 % 10, command[2][1] % 10]
                get_gem(code)
            elif command[1][1] == 1:
                code = [command[2][1], command[2][1]]
                get_gem(code)
            elif command[1][1] == 2:
                code = [command[2][1] // 10, command[2][1] % 10]
                take_card(code)
            elif command[1][1] == 10 and id_last_command == count_of_players:
                count_of_players += 1
                if player_id == 0:
                    player_id = id_last_command + 1
                players.append([[0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0], 0, 0])
            elif command[1][1] == 11:
                if player_id == command[2][1]:
                    sys.exit()
                else:
                    players.pop(-1)
            id_last_command += 1
    if count_of_players >= 2:
        global can_be_start
        can_be_start = True
    for i in range(50):
        if not is_connected:
            break
        time.sleep(0.1)
    if is_connected:
        print(command)
        online()


def get_gem(code):
    player_turn = id_last_command % 4
    for i in range(len(code)):
        players[player_turn][0][code[i] - 1] += 1
        gems[code[i] - 1] -= 1


def take_card(code):
    player_turn = id_last_command % 4
    players[player_turn][1][CARDS[cards_on_desk[code[0] - 1][code[1] - 1]][2]] += 1


def render_setting_window():
    global is_host
    running_2 = True
    textinput = pygame_textinput.TextInputVisualizer()
    textinput.font_object = font3
    clock2 = pygame.time.Clock()
    serv_text = font3.render('Server(link):', True, (0, 0, 0))
    link_type = font3.render('Link on data base on postgres', True, (0, 0, 0))
    host_text = font3.render('Are you host?', True, (0, 0, 0))
    while running_2:
        bg1.draw(sc)
        events = pygame.event.get()
        textinput.update(events)
        sc.blit(textinput.surface, (10 + serv_text.get_size()[0], 10))
        sc.blit(exit_text, exit_text.get_rect(center=(weight // 2, height // 6 * 5)))
        sc.blit(serv_text, (10, 10))
        sc.blit(link_type, (10, 10 + serv_text.get_size()[1]))
        sc.blit(host_text, (10, 10 + 2 * serv_text.get_size()[1]))
        pygame.draw.rect(sc, pygame.Color(0, 0, 0), (10 + host_text.get_size()[0],
                                                     10 + host_text.get_size()[1] * 2,
                                                     host_text.get_size()[1],
                                                     host_text.get_size()[1]), 2)
        if is_host:
            pygame.draw.line(sc, pygame.Color(0, 0, 0), (15 + host_text.get_size()[0],
                                                         13 + host_text.get_size()[1] * 2),
                             (10 + host_text.get_size()[0] + host_text.get_size()[1] // 2,
                              7 + host_text.get_size()[1] * 3))
        for event2 in events:
            if event2.type == pygame.QUIT:
                sys.exit()
            elif event2.type == pygame.MOUSEBUTTONDOWN:
                if right < pygame.mouse.get_pos()[0] < right + exit_text_size[0] // 2 and \
                        height // 6 * 5 - exit_text_size[1] // 2 < pygame.mouse.get_pos()[1] \
                        < height // 6 * 5 + exit_text_size[1]:
                    running_2 = False
                elif 10 + host_text.get_size()[0] < pygame.mouse.get_pos()[0] < 10 + host_text.get_size()[1] + \
                        host_text.get_size()[0] and 10 + host_text.get_size()[1] < pygame.mouse.get_pos()[1] < \
                        10 + host_text.get_size()[1] * 2:

                    is_host = (is_host + 1) % 2
        pygame.display.update()
        clock2.tick(fps)


def save_settings(new_settings):
    f = open('data/other/settings.txt')
    settings = f.read().split('\n')
    f.close()


icon = load_image('icon2.png')
pygame.display.set_icon(icon)

f = open('data/other/settings.txt')
settings = f.read().split('\n')
f.close()
link = settings[3]
name = link[4]
win = StartWindow(sc, info.current_w, info.current_h)

clock = pygame.time.Clock()
fps = 120

running = True
if settings[1] == '0':
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                x, y = event.pos
                if 202 < x < 218 and 182 < y < 198:
                    win.expand()

                elif 20 < x < 40 and 260 < y < 280:
                    win.save_resolution()

                elif 20 < x < 40 and 290 < y < 310:
                    win.change_full_screen()

                elif 220 < x < 280 and 290 < y < 310:
                    win.save_settings()
                    running = False

                elif win.is_expand:
                    if 202 < x < 218 and 202 < y < 218:
                        win.up()

                    elif 202 < x < 218 and 242 < y < 258:
                        win.down()

                    elif 80 < x < 220 and 200 < y < 260:
                        win.select((y - 200) // 20)
        win.render()
        pygame.display.flip()
        clock.tick(fps)

pygame.quit()
pygame.init()
weight, height = map(int, settings[0].split('x'))
sc = pygame.display.set_mode((weight, height))
if settings[2] == '1':
    pygame.display.toggle_fullscreen()
pygame.display.set_icon(icon)
bg1 = pygame.sprite.Group()
bg = pygame.sprite.Sprite(bg1)
bg.image = load_image('bg.png')

bg.rect = (0, 0)

font1 = pygame.font.Font('data/other/Standrag.otf', weight // 8)
font2 = pygame.font.Font('data/other/Standrag.otf', weight // 20)
font3 = pygame.font.Font(None, weight // 20)
header = font1.render('Splendor', True, (200, 200, 100))
new_game = font2.render('New game', True, (0, 0, 0))
size_new_game = new_game.get_size()
settings_label = font2.render('Settings', True, (0, 0, 0))
settings_size = settings_label.get_size()
exit_text = font2.render('Exit', True, (0, 0, 0))
exit_text_size = exit_text.get_size()
right = weight // 2
# if is_host:
# create_table(connection(link))
# th = Thread(target=online)
# th.start()
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if right - size_new_game[0] // 2 < pygame.mouse.get_pos()[0] < size_new_game[0] + weight // 2 \
                    and height // 2 - size_new_game[1] // 2 < pygame.mouse.get_pos()[1] < \
                    size_new_game[1] + height // 2:
                running = False
            elif right - settings_size[0] // 2 < pygame.mouse.get_pos()[0] < settings_size[0] + right \
                    and height // 3 * 2 - settings_size[1] // 2 < pygame.mouse.get_pos()[1] < \
                    settings_size[1] + height // 3 * 2:
                render_setting_window()
            elif right - exit_text_size[0] // 2 < pygame.mouse.get_pos()[0] < exit_text_size[0] + right \
                    and height // 6 * 5 - exit_text_size[1] // 2 < pygame.mouse.get_pos()[1] < height // 6 * 5 + \
                    exit_text_size[1]:
                sys.exit()
    bg1.draw(sc)
    sc.blit(exit_text, exit_text.get_rect(center=(weight // 2, height // 6 * 5)))
    sc.blit(header, (header.get_rect(center=(weight // 2, height // 6))))
    sc.blit(new_game, (new_game.get_rect(center=(weight // 2, height // 2))))
    sc.blit(settings_label, settings_label.get_rect(center=(weight // 2, height // 3 * 2)))
    pygame.display.flip()
    clock.tick(fps)

bg2 = pygame.sprite.Group()
game_bg = pygame.sprite.Sprite(bg2)
game_bg.image = load_image('bg3.png')
game_bg.rect = 0, 0
running = True
gems = pygame.sprite.Group()

dia = Gem('ediamond.png', (weight // 6, 0), gems)
eme = Gem('bemerald.png', (weight // 2, 0), gems)
gol = Gem('zgold.png', (weight // 4 * 3, 0), gems)
oni = Gem('conix.png', (weight // 6, height // 6), gems)
rub = Gem('aruby.png', (weight // 2, height // 6), gems)
sap = Gem('dsapphire.png', (weight // 4 * 3, height // 6), gems)

decks = [random.sample(range(0, 40), 40), random.sample(range(40, 70), 30), random.sample(range(70, 90), 20)]
cards_on_desk = [[-1, -1, -1, -1], [-1, -1, -1, -1], [-1, -1, -1, -1]]
print(False)

for k in range(3):
    for l in range(4):
        cards_on_desk[k][l] = decks[k].pop(l)
print(command)
do_move(connection(link), (command[0][1] + 1, 10, 0, 0))
text_start = font1.render('', True, (0, 0, 0))
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if right - exit_text_size[0] // 2 < pygame.mouse.get_pos()[0] < exit_text_size[0] + right \
                    and height // 6 * 5 - exit_text_size[1] // 2 < pygame.mouse.get_pos()[1] < height // 6 * 5 + \
                    exit_text_size[1]:
                is_connected = False
                running = False
                sys.exit()
            elif right - text_start.get_rect()[0] // 2 < pygame.mouse.get_pos()[0] < right + text_start.get_rect()[0] \
                    and height // 4 - text_start.get_rect()[1] // 2 < pygame.mouse.get_pos()[1] < height // 4 + \
                    text_start.get_rect()[1] // 2:
                pass
    bg2.draw(sc)
    if can_be_start:
        text_start = font1.render('GO!', True, (40, 255, 100))
        pygame.draw.rect(sc, (40, 255, 100), (weight // 3, height // 6, weight // 3, height // 6), 1)
    else:
        text_start = font1.render('WAIT', True, (255, 20, 40))
        pygame.draw.rect(sc, (255, 20, 40), (weight // 3, height // 6, weight // 3, height // 6), 1)
    sc.blit(text_start, text_start.get_rect(center=(weight // 2, height // 4)))
    sc.blit(exit_text, exit_text.get_rect(center=(weight // 2, height // 6 * 5)))
    win.render_preplay_win()
    pygame.display.flip()
    clock.tick(fps)

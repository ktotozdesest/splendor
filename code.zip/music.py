import pygame


def play_bg_music():
    pygame.mixer.music.load('data/music/music1.mp3')
    pygame.mixer.music.play(-1)


def music_volume(volume):
    pygame.mixer.music.set_volume(volume)

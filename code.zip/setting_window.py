import pygame
import button
import checkbox
import image_for_sprite
import music
import pygame_textinput

pygame.init()


class SettingWindow:
    def __init__(self, screen, *size):
        self.sc = screen
        self.wight, self.height = size[0]
        self.bg_group = pygame.sprite.Group()
        bg = pygame.sprite.Sprite(self.bg_group)
        bg.image = image_for_sprite.load_image('bg.png')
        bg.rect = (0, 0)
        font = pygame.font.Font('data/other/Standrag.otf', self.wight // 20)
        st_font = pygame.font.Font(None, self.wight // 25)
        exit_text = font.render('Exit', True, (0, 0, 0))
        self.button_exit = button.Button(self.sc, exit_text.get_rect(center=(self.wight // 2, self.height // 5 * 4)),
                                         text=exit_text, weight=-1)
        self.chechbox = checkbox.Chechbox(self.sc, (self.wight // 50, self.height // 5 * 4,
                                                    self.wight // 20, self.wight // 20),
                                          name_font_color=(
                                              'Save', pygame.font.Font(None, self.wight // 20), pygame.Color(0, 0, 0)),
                                          weight=4)
        self.text_link = st_font.render('Link on database in /Splendor/data/other/settings.txt 4 string', True,
                                        (0, 0, 0))
        self.text_volume = st_font.render('Volume(%):', True, (0, 0, 0))
        self.volume_input = pygame_textinput.TextInputVisualizer()
        self.chech_volume = st_font.render('Check volume', True, (0, 0, 0))
        self.volume_button = button.Button(self.sc, (
            self.chech_volume.get_size()[0] + 30, self.text_link.get_size()[1] + self.text_volume.get_size()[1] + 30,
            self.wight // 20, self.wight // 20),
                                           weight=0)
        self.wrong_value = st_font.render('Wrong value of volume', True, (255, 0, 0))
        self.wrong = False

    def render(self):
        self.bg_group.draw(self.sc)
        self.button_exit.render()
        self.chechbox.render()
        self.sc.blit(self.text_link, (20, 20))
        self.sc.blit(self.text_volume, (20, self.text_link.get_size()[1] + 30))
        self.sc.blit(self.volume_input.surface,
                     (self.text_volume.get_size()[0] + 30, self.text_link.get_size()[1] + 32))
        self.sc.blit(self.chech_volume, (20, self.text_link.get_size()[1] + self.text_volume.get_size()[1] + 30))
        self.volume_button.render()
        if self.wrong:
            self.sc.blit(self.wrong_value, self.wrong_value.get_rect(center=(self.wight // 2, self.height // 2)))

    def clicked(self, event):
        if self.button_exit.clicked(event):
            return 1
        elif self.volume_button.clicked(event):
            try:
                music.music_volume(int(self.volume_input.value) / 100)
            except TypeError:
                self.wrong = True
            except ValueError:
                self.wrong = True
        else:
            self.wrong = False

        self.chechbox.change_flag(event)

    def update(self, events):
        self.volume_input.update(events)

    def save(self):
        try:
            with open('data/other/settings.txt') as file:
                settings = file.read().split('\n')
                settings[5] = str(int(self.volume_input.value) / 100)
                file.close()
            settings = '\n'.join(settings)
            with open('data/other/settings.txt', 'w') as file:
                file.write(settings)
        except ValueError:
            self.wrong = True


if __name__ == '__main__':
    size = width, height = 1024, 768
    sc = pygame.display.set_mode(size)
    window = SettingWindow(sc, size)
    clock = pygame.time.Clock()
    music.play_bg_music()
    FPS = 60
    running = True
    while running:
        events = pygame.event.get()
        window.volume_input.update(events)
        for event in events:
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                output = window.clicked(event)
                if output == 1:
                    if window.chechbox.flag:
                        window.save()
                    running = False
        window.render()
        pygame.display.flip()
        clock.tick(FPS)

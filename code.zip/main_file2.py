import pygame
import start_window
import main_window
import music
import setting_window
import game_window
import deck_on_desk
import earls
import sys
import base_of_online
import threading
import connection_window

pygame.init()
info = pygame.display.Info()
wight, height = 300, 340
sc = pygame.display.set_mode((wight, height))
pygame.display.set_caption('Splendor')
win = start_window.StartWindow(sc, info.current_w, info.current_h)

clock = pygame.time.Clock()
fps = 60

running = True
with open('data/other/settings.txt') as file:
    settings = file.read().split('\n')
    file.close()

if settings[1] == '0':
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN:
                win.checkbox1.change_flag(event)
                win.checkbox2.change_flag(event)
                if win.button.clicked(event):
                    win.save_settings()
                    running = False

                elif win.button_expand.clicked(event):
                    win.expand()

                elif win.is_expand:
                    x, y = event.pos
                    if 202 < x < 218 and 202 < y < 218:
                        win.up()

                    elif 202 < x < 218 and 242 < y < 258:
                        win.down()

                    elif 80 < x < 220 and 200 < y < 260:
                        win.select((y - 200) // 20)
        win.render()
        pygame.display.flip()
        clock.tick(fps)

with open('data/other/settings.txt') as file:
    settings = file.read().split('\n')
    file.close()
pygame.quit()
pygame.init()
size = wight, height = list(map(int, settings[0].split('x')))
sc = pygame.display.set_mode((wight, height))
if settings[2] == '1':
    pygame.display.toggle_fullscreen()
window = main_window.MainWindow(sc, size)
music.play_bg_music()
music.music_volume(float(settings[5]))
running = True
FPS = 60
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            output = window.clicked(event)
            if output == 0:
                running = False
            elif output == 1:
                window_set = setting_window.SettingWindow(sc, size)
                clock2 = pygame.time.Clock()
                running_2 = True
                while running_2:
                    events = pygame.event.get()
                    window_set.volume_input.update(events)
                    for event in events:
                        if event.type == pygame.QUIT:
                            sys.exit()
                        elif event.type == pygame.MOUSEBUTTONDOWN:
                            output = window_set.clicked(event)
                            if output == 1:
                                if window_set.chechbox.flag:
                                    window_set.save()
                                running_2 = False
                    window_set.render()
                    pygame.display.flip()
                    clock2.tick(FPS)
            elif output == 2:
                running_2 = True
                with open('data/other/settings.txt') as file:
                    link = file.read().split('\n')[3]
                    file.close()
                thread = threading.Thread(target=base_of_online.online(base_of_online.connection(link)), daemon=True)
                window_conn = connection_window.ConnectWindow(sc, size)
                count_of_players = base_of_online.count_of_players
                last_code = base_of_online.last_code

                while running_2:
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT:
                            sys.exit()
                        elif event.type == pygame.MOUSEBUTTONDOWN:
                            output = window_conn.clicked(event)
                            if output == -1:
                                sys.exit()
                            elif output == 1:
                                gems = ['diamond', 'emerald', 'onyx', 'ruby', 'sapphire']
                                decks = deck_on_desk.set_decks()
                                cards_on_desk = [[-1, -1, -1, -1], [-1, -1, -1, -1], [-1, -1, -1, -1]]
                                decks, cards_on_desk = deck_on_desk.set_desk(decks, cards_on_desk)
                                cards = deck_on_desk.get_cards(cards_on_desk)
                                earls_list = earls.get_earls(count_of_players)
                                game = game_window.GameRender(sc, size, count_of_players, cards, cards_on_desk,
                                                              earls_list)
                                running_3 = True
                                while running_3:
                                    game.render()
                                    pygame.display.flip()
                                    for event in pygame.event.get():
                                        if event.type == pygame.QUIT:
                                            sys.exit()
                                        elif event.type == pygame.MOUSEBUTTONDOWN:
                                            output = game.clicked(event)
                                            print(output)
                                            if output == -1:
                                                pass
                                    window.render()
                                    pygame.display.flip()

import pygame
import button

count_of_player = 1
pygame.init()


class ConnectWindow:
    def __init__(self, screen, *size):
        self.size = size[0]
        self.sc = screen
        font = pygame.font.Font(None, self.size // 5)
        self.text = font.render(str(count_of_player), True, (0, 0, 0))
        self.button = button.Button(self.sc, (self.size[0] // 3, self.size[1] // 2,
                                              self.size[0] // 3, self.size[1] // 4),
                                    weight=-1,
                                    text=pygame.font.Font(None, size[1] // 10).render('Start', True, (0, 0, 0)))
        self.button_ex = button.Button(self.sc, (self.size[0] // 3, self.size[1] // 4 * 3,
                                                 self.size[0] // 3, self.size[1] // 4),
                                       weight=-1,
                                       text=pygame.font.Font(None, size[1] // 10).render('Exit', True, (0, 0, 0)))

    def render(self):
        self.sc.fill(pygame.Color(255, 255, 255))
        self.button_ex.render()
        if count_of_player >= 2:
            self.button.render()

    def clicked(self, event):
        if self.button_ex.clicked(event):
            return -1
        elif count_of_player >- 2 and self.button.clicked(event):
            return 1

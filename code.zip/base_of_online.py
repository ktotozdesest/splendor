import urllib.parse as up
import psycopg2
import copy
import time

is_host = False
last_code = [(0, -1), (1, -1), (2, -1), (3, -1), (4, -1)]
count_of_players = 1
connected = False
start_game = False
id = 0


def connection(link):
    try:
        up.uses_netloc.append("postgres")
        url = up.urlparse(link)

        conn = psycopg2.connect(database=url.path[1:], user=url.username, password=url.password,
                                host=url.hostname,
                                port=url.port)
        return conn
    except psycopg2.OperationalError:
        return -1


def update(conn):
    cur = conn.cursor()
    cur.execute("""SELECT * FROM codes;""")
    result = cur.fetchall()
    cur.close()
    return result


def do_move(conn, move):
    cur = conn.cursor()
    for i in range(5):
        cur.execute(f"""UPDATE codes SET code={move[i]} WHERE id = {i}""")
    cur.close()
    conn.commit()


def create_table(conn):
    cur = conn.cursor()
    cur.execute("""DROP TABLE codes;""")
    cur.execute("""CREATE TABLE IF NOT EXISTS codes (
                        id integer,
                        code integer);""")
    for i in range(5):
        cur.execute(f"""INSERT INTO codes VALUES ({i}, 0);""")
    cur.close()
    conn.commit()


def online(conn):
    global is_host
    global last_code
    global count_of_players
    global connected
    global start_game
    global id
    cur = conn.cursor()
    cur.execute('''SELECT * FROM codes''')
    code = cur.fetchall()
    print(is_host)
    if code[4][1] == 0:
        print(4)
        is_host = True
    if is_host and code[0][1] == 0 and not connected:
        create_table(conn)
        do_move(conn, [code[0][1] + 1, 0, 0, 0, 1])
        id = 0
        connected = True
    elif not is_host and not connected:
        do_move(conn, [code[0][1] + 1, 10, 0, 0, 1])
        count_of_players = code[0][1]
        connected = True
        id = code[0][1] - 1
    if code[0][1] != last_code[0][1]:
        if code[1][1] == 10:
            count_of_players += 1
        elif code[1][1] == 11:
            count_of_players -= 1
        elif code[1][1] == 12:
            start_game = True
    print(last_code)
    last_code = copy.deepcopy(code)
    print(code, count_of_players, is_host)
    time.sleep(5)


if __name__ == '__main__':
    with open('data/other/settings.txt') as file:
        link = file.read().split('\n')[3]
        file.close()
    conn = connection(link)
    create_table(conn)
    code = int(input())
    while code != -1:
        online(conn)
        code = int(input())
        qcode = update(conn)
        if code == 1:
            do_move(conn, [qcode[0][1] + 1, 0, 0, 0, 1])
        elif code == 2:
            do_move(conn, [qcode[0][1] + 1, 12, 0, 0, 1])
        if start_game:
            all_gems = [7, 7, 7, 7, 7]
            my_player = [[0, 0, 0, 0, 0], [0, 0, 0, 0, 0], 0]
            other_players = [[0, 0, 0, 0, 0], [0, 0, 0, 0, 0], 0] * (count_of_players - 1)
            turn = 0
            print(other_players)
    # id 0 номер команды id 4 состояние игры

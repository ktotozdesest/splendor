import pygame
import checkbox
import button

pygame.init()

RESOLUTIONS = {'r0': '1366x768', 'r1': '1920x1080', 'r2': '1536x864',
               'r3': '1440x900', 'r4': '1280x720', 'r5': '1600x900',
               'r6': '1280x800', 'r7': '1280x1024', 'r8': '1024x768'}


class StartWindow:
    def __init__(self, screen, weight_of_window, height_of_window):
        self.screen = screen

        self.recommended_resolution = f'{weight_of_window}x{height_of_window}'

        self.font1 = pygame.font.Font(None, 24)
        self.font2 = pygame.font.Font(None, 20)
        self.font3 = pygame.font.Font(None, 52)
        self.header = self.font3.render('Splendor', True, (0, 0, 0))
        self.now_resolution_text = self.font1.render(self.recommended_resolution,
                                                     True, (0, 0, 0))
        self.text = self.font1.render("Разрешение", True, (0, 0, 0))
        self.black = pygame.color.Color(0, 0, 0)

        self.is_expand = False
        self.y = {'y_line1': 220, 'y_line2': 240}
        self.resolution_index = 0
        self.is_selected = [0, 0, 0]
        self.now_resolution = self.recommended_resolution

        self.checkbox1 = checkbox.Chechbox(self.screen, (20, 260, 20, 20),
                                           name_font_color=('Сохранить и больше не показывать', self.font2,
                                                            self.black))
        self.checkbox2 = checkbox.Chechbox(self.screen, (20, 290, 20, 20),
                                           name_font_color=('Полный экран', self.font2, self.black))

        self.button = button.Button(self.screen, (220, 290, 60, 20),
                                    name_font_color=('Далее', self.font1, self.black))

        self.button_expand = button.Button(self.screen, (202, 182, 16, 16),
                                           name_font_color=('V', self.font2, self.black))
        self.button_up = button.Button(self.screen, (202, 202, 16, 16),
                                       name_font_color=('^', self.font1, self.black))
        self.button_down = button.Button(self.screen, (202, 242, 16, 16),
                                         name_font_color=('V', self.font2, self.black))

    def render(self):
        self.screen.fill(pygame.Color(255, 255, 255))

        self.screen.blit(self.text, (91, 162))
        self.screen.blit(self.header, (72, 40))

        self.screen.blit(self.now_resolution_text, (91, 182))
        pygame.draw.rect(self.screen, pygame.Color(0, 0, 0), (80, 180, 140, 20), 1)

        self.button_expand.render()
        self.button.render()
        self.checkbox1.render()
        self.checkbox2.render()

        if self.is_expand:
            if 1 in self.is_selected:
                selected_section = self.is_selected.index(1)
                pygame.draw.rect(self.screen, pygame.Color(42, 156, 235),
                                 (80, 200 + selected_section * 20, 120, 20), 0)

            pygame.draw.rect(self.screen, pygame.Color(0, 0, 0), (80, 200, 140, 60), 1)
            pygame.draw.rect(self.screen, pygame.Color(0, 0, 0), (200, 200, 20, 60), 1)

            self.button_up.render()
            self.button_down.render()

            for i in range(2):
                pygame.draw.line(self.screen, pygame.Color(0, 0, 0), (80, self.y[f'y_line{i + 1}']),
                                 (200, self.y[f'y_line{i + 1}']), 1)
            for i in range(3):
                resolution = self.font1.render(RESOLUTIONS[f'r{(self.resolution_index + i) % 9}'], True, (0, 0, 0))
                self.screen.blit(resolution, (91, 202 + i * 20))

    def expand(self):
        self.is_expand = (self.is_expand + 1) % 2

    def up(self):
        self.resolution_index -= 1

    def down(self):
        self.resolution_index += 1

    def select(self, section):
        if self.is_selected[section] == 1:
            self.now_resolution = RESOLUTIONS[f'r{(self.resolution_index + section) % 9}']
            self.now_resolution_text = self.font1.render(self.now_resolution,
                                                         True, (0, 0, 0))
        self.is_selected = [0] * 3
        self.is_selected[section] = 1

    def save_settings(self):
        f1 = open('data/other/settings.txt', mode='r')
        setting_res = f1.read().split('\n')
        f1.close()
        f1 = open('data/other/settings.txt', mode='w')
        setting_res[0] = self.now_resolution
        setting_res[1] = str(self.checkbox1.flag)
        setting_res[2] = str(self.checkbox2.flag)
        for i in range(len(setting_res) - 1):
            setting_res[i] = setting_res[i] + '\n'
        for elem in setting_res:
            f1.write(elem)
        f1.close()


if __name__ == '__main__':
    info = pygame.display.Info()
    weight, height = 300, 340
    sc = pygame.display.set_mode((weight, height))
    pygame.display.set_caption('Splendor')
    win = StartWindow(sc, info.current_w, info.current_h)

    clock = pygame.time.Clock()
    fps = 60

    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN:
                win.checkbox1.change_flag(event)
                win.checkbox2.change_flag(event)
                if win.button.clicked(event):
                    win.save_settings()
                    running = False

                elif win.button_expand.clicked(event):
                    win.expand()

                elif win.is_expand:
                    x, y = event.pos
                    if 202 < x < 218 and 202 < y < 218:
                        win.up()

                    elif 202 < x < 218 and 242 < y < 258:
                        win.down()

                    elif 80 < x < 220 and 200 < y < 260:
                        win.select((y - 200) // 20)
        win.render()
        pygame.display.flip()
        clock.tick(fps)

import pygame
import button
import image_for_sprite
import music

pygame.init()


class MainWindow:
    def __init__(self, screen, *size):
        self.sc = screen
        self.wight, self.height = size[0]
        self.bg_group = pygame.sprite.Group()
        bg = pygame.sprite.Sprite(self.bg_group)
        bg.image = image_for_sprite.load_image('bg.png')
        bg.rect = (0, 0)
        font1 = pygame.font.Font('data/other/Standrag.otf', self.wight // 8)
        font2 = pygame.font.Font('data/other/Standrag.otf', self.wight // 20)
        self.header = font1.render('Splendor', True, (200, 200, 100))
        new_game = font2.render('New game', True, (0, 0, 0))
        settings = font2.render('Settings', True, (0, 0, 0))
        exit_txt = font2.render('Exit', True, (0, 0, 0))
        self.button_ng = button.Button(self.sc, new_game.get_rect(center=(self.wight // 2, self.height // 2)),
                                       weight=-1, text=new_game)
        self.button_set = button.Button(self.sc, settings.get_rect(center=(self.wight // 2, self.height // 3 * 2)),
                                        weight=-1, text=settings)
        self.button_ex = button.Button(self.sc, exit_txt.get_rect(center=(self.wight // 2, self.height // 6 * 5)),
                                       weight=-1, text=exit_txt)

    def render(self):
        self.bg_group.draw(self.sc)
        self.sc.blit(self.header, self.header.get_rect(center=(self.wight // 2, self.height // 6)))
        self.button_ex.render()
        self.button_set.render()
        self.button_ng.render()

    def clicked(self, event):
        if self.button_ex.clicked(event):
            return 0
        elif self.button_set.clicked(event):
            return 1
        elif self.button_ng.clicked(event):
            return 2


if __name__ == '__main__':
    size = width, height = 1024, 768
    sc = pygame.display.set_mode(size)
    window = MainWindow(sc, size)
    music.play_bg_music()
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                output = window.clicked(event)
                print(output)
        window.render()
        pygame.display.flip()

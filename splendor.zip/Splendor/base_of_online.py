import pygame
import urllib.parse as up
import psycopg2
from threading import Thread
import time


def do_move(cur, conn, *ids):
    for i in range(4):
        cur.execute(f'''UPDATE codes SET code = {ids[0][i]} WHERE id = {i}''')
        conn.commit()


def update_data():
    try:
        up.uses_netloc.append("postgres")
        url = up.urlparse("postgres://luvyqlkq:RX3Q9kAnvsiP1rYxlKxdBBs5bPo_gmEo@surus.db.elephantsql.com/luvyqlkq")

        conn = psycopg2.connect(database=url.path[1:], user=url.username, password=url.password,
                                host=url.hostname,
                                port=url.port)
        cur = conn.cursor()
        cur.execute("""SELECT * FROM codes;""")
        result = cur.fetchall()
        print(result)
        cur.close()
        conn.close()
        time_of_sleep = 5
        running_of_update = True
        for i in range(time_of_sleep):
            time.sleep(1)
            global flag
            if not flag:
                running_of_update = False
                break
        if running_of_update:
            update_data()
    except psycopg2.OperationalError:
        flag = False


tick_of_start = 0
tick_update = 0
tick_now = 0

pygame.init()
weight, height = 960, 540
sc = pygame.display.set_mode((weight, height))

pygame.mixer.music.load('data/music/music1.mp3')
pygame.mixer.music.play(-1)

sound1 = pygame.mixer.Sound('data/music/take_gem.wav')

clock = pygame.time.Clock()

running = True
fps = 60
th = Thread(target=update_data)
flag = True
th.start()
while running:
    for event in pygame.event.get():
        tick_now = pygame.time.get_ticks()
        if event.type == pygame.QUIT:
            flag = False
            running = False

        elif event.type == pygame.MOUSEBUTTONDOWN and tick_now > tick_of_start and event.button == 1:
            sound1.play()
            tick_of_start = pygame.time.get_ticks() + fps * 18

        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 3:
            up.uses_netloc.append("postgres")
            url = up.urlparse(
                "postgres://luvyqlkq:RX3Q9kAnvsiP1rYxlKxdBBs5bPo_gmEo@surus.db.elephantsql.com/luvyqlkq")

            conn = psycopg2.connect(database=url.path[1:], user=url.username, password=url.password,
                                    host=url.hostname,
                                    port=url.port)
            cur = conn.cursor()
            ids = int(input()), int(input()), int(input()), int(input())
            do_move(cur, conn, ids)
            cur.close()
            conn.close()
    pygame.display.flip()
    clock.tick(fps)

import pygame

pygame.init()
info = pygame.display.Info()
weight, height = 300, 300
sc = pygame.display.set_mode((weight, height))
pygame.display.set_caption('Splendor')

RESOLUTIONS = {'r0': '1366х768', 'r1': '1920х1080', 'r2': '1536х864',
               'r3': '1440х900', 'r4': '1280х720', 'r5': '1600х900',
               'r6': '1280х800', 'r7': '1280х1024', 'r8': '1024х768'}


class StartWindow:
    def __init__(self, screen, weight_of_window, height_of_window):
        self.screen = screen

        self.recommended_resolution = weight_of_window, height_of_window

        self.font1 = pygame.font.Font(None, 24)
        self.font2 = pygame.font.Font(None, 20)
        self.recommended_resolution = self.font1.render(f"{weight_of_window}x{height_of_window}",
                                                        True, (0, 0, 0))
        self.text = self.font1.render("Разрешение", True, (0, 0, 0))
        self.save_resolution_1 = self.font2.render('Сохранить настройки и', True, (0, 0, 0))
        self.save_resolution_2 = self.font2.render(' больше не показывать', True, (0, 0, 0))

        self.next = self.font1.render('Далее', True, (0, 0, 0))

        self.is_expand = False
        self.is_save = False
        self.y = {'y_line1': 220, 'y_line2': 240}
        self.resolution_index = 0
        self.is_selected = [0, 0, 0]
        self.now_resolution = self.recommended_resolution

    def render(self):
        self.screen.fill(pygame.Color(255, 255, 255))

        self.screen.blit(self.text, (91, 162))

        self.screen.blit(self.now_resolution, (91, 182))
        pygame.draw.rect(self.screen, pygame.Color(0, 0, 0), (80, 180, 140, 20), 1)

        pygame.draw.rect(self.screen, pygame.Color(0, 0, 0), (202, 182, 16, 16), 1)

        pygame.draw.line(self.screen, pygame.Color(0, 0, 0), (206, 188), (209, 192), 2)
        pygame.draw.line(self.screen, pygame.Color(0, 0, 0), (209, 192), (212, 188), 2)

        pygame.draw.rect(self.screen, pygame.Color(0, 0, 0), (20, 260, 20, 20), 1)
        self.screen.blit(self.save_resolution_1, (40, 260))
        self.screen.blit(self.save_resolution_2, (40, 270))

        pygame.draw.rect(self.screen, pygame.Color(0, 0, 0), (220, 260, 60, 20), 1)
        self.screen.blit(self.next, (222, 262))

        if self.is_save:
            pygame.draw.line(self.screen, pygame.Color(0, 0, 0), (24, 268), (30, 276), 3)
            pygame.draw.line(self.screen, pygame.Color(0, 0, 0), (30, 276), (36, 264), 3)

        if self.is_expand:
            if 1 in self.is_selected:
                selected_section = self.is_selected.index(1)
                pygame.draw.rect(self.screen, pygame.Color(42, 156, 235),
                                 (80, 200 + selected_section * 20, 120, 20), 0)

            pygame.draw.rect(self.screen, pygame.Color(0, 0, 0), (80, 200, 140, 60), 1)
            pygame.draw.rect(self.screen, pygame.Color(0, 0, 0), (200, 200, 20, 60), 1)

            pygame.draw.rect(self.screen, pygame.Color(0, 0, 0), (202, 202, 16, 16), 1)
            pygame.draw.rect(self.screen, pygame.Color(0, 0, 0), (202, 242, 16, 16), 1)

            pygame.draw.line(self.screen, pygame.Color(0, 0, 0), (206, 248), (209, 252), 2)
            pygame.draw.line(self.screen, pygame.Color(0, 0, 0), (209, 252), (212, 248), 2)

            pygame.draw.line(self.screen, pygame.Color(0, 0, 0), (206, 212), (209, 208), 2)
            pygame.draw.line(self.screen, pygame.Color(0, 0, 0), (209, 208), (212, 212), 2)

            for i in range(2):
                pygame.draw.line(self.screen, pygame.Color(0, 0, 0), (80, self.y[f'y_line{i + 1}']),
                                 (200, self.y[f'y_line{i + 1}']), 1)
            for i in range(3):
                resolution = self.font1.render(RESOLUTIONS[f'r{(self.resolution_index + i) % 9}'], True, (0, 0, 0))
                self.screen.blit(resolution, (91, 202 + i * 20))

    def expand(self):
        self.is_expand = (self.is_expand + 1) % 2

    def up(self):
        self.resolution_index -= 1

    def down(self):
        self.resolution_index += 1

    def select(self, section):
        if self.is_selected[section] == 1:
            self.now_resolution = self.font1.render(RESOLUTIONS[f'r{(self.resolution_index + section) % 9}'],
                                                    True, (0, 0, 0))
        self.is_selected = [0] * 3
        self.is_selected[section] = 1

    def save_resolution(self):
        self.is_save = (self.is_save + 1) % 2


win = StartWindow(sc, info.current_w, info.current_h)

clock = pygame.time.Clock()
fps = 60

running = True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        elif event.type == pygame.MOUSEBUTTONDOWN:
            x, y = event.pos
            if 202 < x < 218 and 182 < y < 198:
                win.expand()

            if 20 < x < 40 and 260 < y < 280:
                win.save_resolution()

            if win.is_expand:
                if 202 < x < 218 and 202 < y < 218:
                    win.up()

                elif 202 < x < 218 and 242 < y < 258:
                    win.down()

                elif 80 < x < 220 and 200 < y < 260:
                    win.select((y - 200) // 20)

    win.render()
    pygame.display.flip()

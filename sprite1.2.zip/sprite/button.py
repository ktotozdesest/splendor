import pygame

pygame.init()


class Button:
    def __init__(self, screen, *pos, color=pygame.Color(0, 0, 0),
                 name_font_color=('', pygame.font.Font(None, 0), pygame.Color(0, 0, 0)),
                 pos_text=(0, 0), weight=1, text=None):
        self.sc = screen
        self.color = color
        self.pos = pos[0]
        if text is not None:
            self.text = text
        else:
            self.font = name_font_color[1]
            self.text = self.font.render(name_font_color[0], True, name_font_color[2])
        self.weight_border = weight
        if pos_text == (0, 0):
            self.pos_text = (0, 0)
        else:
            self.pos_text = pos_text

    def render(self):
        pygame.draw.rect(self.sc, self.color, self.pos, self.weight_border)
        if self.pos_text == (0, 0):
            self.sc.blit(self.text,
                         self.text.get_rect(center=(self.pos[0] + self.pos[2] // 2, self.pos[1] + self.pos[3] // 2)))
        else:
            self.sc.blit(self.text, self.pos_text)

    def clicked(self, event):
        if self.pos[0] < event.pos[0] < self.pos[0] + self.pos[2] and \
                self.pos[1] < event.pos[1] < self.pos[1] + self.pos[3]:
            return True


if __name__ == '__main__':
    wight, height = 300, 340
    font2 = pygame.font.Font('data/other/Standrag.otf', wight // 20)
    sc = pygame.display.set_mode((wight, height))
    button = Button(sc, (10, 10, 150, 50), color=pygame.Color(0, 255, 0), weight=-1,
                    name_font_color=('name', pygame.font.Font(None, 24), pygame.Color(0, 0, 255)),
                    pos_text=(0, 0))
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        sc.fill(pygame.Color(255, 255, 255))
        button.render()
        pygame.display.flip()
